# Memory Game Project

# what is the Memory game look like 
this is game was built to test your memory and making it strongand fast. here's a deck cards with different icons. 

# the amazing challenge 
the challenge here is two catch match cards in less time with less moves.

# how to play it
you have to catch 2 similar card until you finish all the cards, use your memory to catch the right symbol in short time and less move. you can have a look https://codepen.io/Suzy_Nazmy/pen/xWXgwv  

# How I built the Memory game
I manipulated the DOM with Js, altered part of the HTML and also styled the game.
*  designed a deck of cards that shuffles when game is refreshed or reset.
* designed a counter to count the number of moves made by player and timer to know the duration of a play.
* added some effects to cards when they match and are unmatched.
* create a pop-up message when player wins game.

# project description

* Memory Game: The game randomly shuffles the cards.the players win once all cards have been matched.  

* Star Rating: the game displays a star rating that reflects the player's performance. After some number of moves, it should change to a 2 star rating, and so on.

* Timer: as soon as the player starts a game, a timer will start. when the player wins the game, the timer stops right away.

* Move Counter: The game shows the current steps of moves a user has made.

* Restart Button: A restart button lets the player reset the game, the timer, move counter, and the star rating.

* Congratulations Popup: When a player wins the game, a modal appears to congratulate the player and ask if they want to play again. also, the time he took, a number of moves, and the rating.